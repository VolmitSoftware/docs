## What changed

<!-- Which pages, and why -->

## Checklist

- [ ] Frontmatter intact on every edited file
- [ ] Internal links use absolute page paths (`/iris/commands`)
- [ ] Command syntax follows `<required>` / `[optional]`
- [ ] Destructive behaviour carries an `{.is-warning}` or `{.is-danger}` callout
- [ ] Not editing a page ported from a plugin repo's `docs/` (fix upstream instead)
- [ ] Behaviour verified against source on the correct branch
